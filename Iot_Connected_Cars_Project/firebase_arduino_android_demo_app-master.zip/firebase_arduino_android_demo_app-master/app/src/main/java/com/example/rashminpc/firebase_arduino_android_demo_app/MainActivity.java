package com.example.rashminpc.firebase_arduino_android_demo_app;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();

    final DatabaseReference Car1X = myRef.child("Car1").child("X");

    final DatabaseReference Car1Y = myRef.child("Car1").child("Y");

    final DatabaseReference Car2X = myRef.child("Car2").child("X");

    final DatabaseReference Car2Y = myRef.child("Car2").child("Y");
    final DatabaseReference Coin1=myRef.child("Coin1");
    final DatabaseReference Coin2=myRef.child("Coin2");
    final DatabaseReference Coin3=myRef.child("Coin3");
    final DatabaseReference Coin4=myRef.child("Coin4");
    final DatabaseReference Coin5=myRef.child("Coin5");
    final DatabaseReference Coin6=myRef.child("Coin6");







    TextView textView1;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    int counter=1;
    public void coin_select(View view){
        try{
        if(counter<7){

        Button selected =(Button)view;
      //  selected.setVisibility(View.INVISIBLE);
        selected.setClickable(false);
        selected.setBackgroundResource(R.drawable.coin);
      String to_send= String.valueOf(selected.getText());
      selected.setText("");
      to_send=to_send.replaceAll(",","");
      int send= Integer.parseInt(to_send);
      String coin ="Coin"+counter;
      myRef.child(coin).setValue(send);

        counter++;
        if(counter==6){
            myRef.child("Ready").setValue(1);
        }
        }



        else{
            Toast.makeText(this, "6 coins already placed",
                    Toast.LENGTH_LONG).show();        }

    }
catch(Exception e){
        e.printStackTrace();
    }}


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Coin1.setValue("0");
        Coin2.setValue("0");
        Coin3.setValue("0");
        Coin4.setValue("0");
        Coin5.setValue("0");
        Coin6.setValue("0");
        myRef.child("Ready").setValue(0);



        textView1 = (TextView)findViewById(R.id.textView1);
        textView2 = (TextView)findViewById(R.id.textView2);
        textView3 = (TextView)findViewById(R.id.textView3);
        textView4 = (TextView)findViewById(R.id.textView4);
        //updateText(ledstatus1,textView1);

        Car1X.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue().toString();
                Log.d("file", "Value is: " + value);
                textView1.setText(value);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("file", "Failed to read value.", error.toException());
            }
        });
        Car1Y.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value =  dataSnapshot.getValue().toString();
                Log.d("file", "Value is: " + value);
                textView2.setText(value+"");

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("file", "Failed to read value.", error.toException());
            }
        });
        Car2X.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue().toString();
                Log.d("file", "Value is: " + value);
                textView3.setText(value);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("file", "Failed to read value.", error.toException());
            }
        });
        Car2Y.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue().toString();
                Log.d("file", "Value is: " + value);
                textView4.setText(value);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("file", "Failed to read value.", error.toException());
            }
        });







    }
}